package com.iba.iot.datasimulator.definition.model;

import com.iba.iot.datasimulator.common.model.schema.SchemaViews;

/**
 *
 */
public interface DataDefinitionViews {

    /**
     *
     */
    interface Short extends DatasetViews.Short, SchemaViews.Short {}

}
