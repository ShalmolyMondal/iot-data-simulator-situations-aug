export default {
    fields: {
        datasetUpload: {
            type: 'file',
            rules: "required"
        }
    }
};