import { FieldState } from "formstate";

export default class FixedFieldState extends FieldState {}