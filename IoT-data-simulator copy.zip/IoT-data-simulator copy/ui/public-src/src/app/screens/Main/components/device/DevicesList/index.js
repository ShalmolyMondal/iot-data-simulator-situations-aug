import DevicesList from './DevicesList';
export default DevicesList;