import DeviceListItem from './DeviceListItem';
export default DeviceListItem;