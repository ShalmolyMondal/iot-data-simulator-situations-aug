package com.iba.iot.datasimulator.common.model.schema.property;

/**
 *
 */
public interface SessionArraySchemaProperty extends ArraySchemaProperty, SessionSchemaProperty {}
