import ChevronUpIcon from './ChevronUpIcon';
import DeleteIcon from './DeleteIcon';
import EraserIcon from './EraserIcon';
import PauseIcon from './PauseIcon';
import PlayIcon from './PlayIcon';
import StopIcon from './StopIcon';

export default {
    ChevronUpIcon,
    DeleteIcon,
    EraserIcon,
    PauseIcon,
    PlayIcon,
    StopIcon,
}