export default {

    /** **/
    websocketUrl: 'http://services:8080/ws',

    /** **/
    isStompTracingEnabled: false,

    /** **/
    reconnectionInterval: 3000,

}