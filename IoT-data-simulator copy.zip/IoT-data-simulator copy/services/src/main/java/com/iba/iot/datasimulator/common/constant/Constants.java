package com.iba.iot.datasimulator.common.constant;

/**
 * Created by Alex on 13.09.2017.
 */
public interface Constants {

    String ID_FIELD = "_id";
}
