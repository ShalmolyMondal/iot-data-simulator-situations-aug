package com.iba.iot.datasimulator.session.service.seed;

import java.io.IOException;

/**
 *
 */
public interface SeedSessionImporter {

    /**
     *
     */
    void process() throws IOException;

}
