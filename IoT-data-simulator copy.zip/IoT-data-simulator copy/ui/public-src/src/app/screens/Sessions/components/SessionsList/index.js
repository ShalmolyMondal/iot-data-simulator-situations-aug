import SessionsList from './SessionsList';
export default SessionsList;