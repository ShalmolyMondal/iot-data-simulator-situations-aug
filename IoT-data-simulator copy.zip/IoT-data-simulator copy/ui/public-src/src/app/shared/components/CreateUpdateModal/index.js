import CreateUpdateModal from './CreateUpdateModal';
export default CreateUpdateModal;