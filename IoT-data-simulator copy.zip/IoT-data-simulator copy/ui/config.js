

module.exports = {
    websocketUrl: process.env.WEBSOCKET_URL,
    restUrl: process.env.REST_URL
}