package com.iba.iot.datasimulator.definition.model;

/**
 *
 */
public interface DatasetViews {

    /**
     *
     */
    interface Short {}
}
