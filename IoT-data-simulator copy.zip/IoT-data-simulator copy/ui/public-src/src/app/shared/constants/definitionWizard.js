
export const DatasetSelectionMethods = {
    existing: 'existing',
    bucket: 'bucket',
    upload: 'upload'
}