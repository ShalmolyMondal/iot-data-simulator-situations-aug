package com.iba.iot.datasimulator.common.model;

/**
 *
 * @param <T>
 */
public interface TypedEntity<T> {

    /**
     *
     * @return
     */
    T getType();

}
