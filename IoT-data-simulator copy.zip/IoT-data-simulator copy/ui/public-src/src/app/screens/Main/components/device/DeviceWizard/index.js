import DeviceWizard from './DeviceWizard';
export default DeviceWizard;