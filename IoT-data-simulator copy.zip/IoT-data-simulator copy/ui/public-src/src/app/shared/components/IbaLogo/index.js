import IbaLogo from './IbaLogo';
export default IbaLogo;