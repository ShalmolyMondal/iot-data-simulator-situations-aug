import DeleteModal from './DeleteModal';
export default DeleteModal;