import ControlPanel from './ControlPanel';
export default ControlPanel;