package com.iba.iot.datasimulator.common.model.schema.property;

public interface SessionObjectSchemaProperty extends ObjectSchemaProperty, SessionSchemaProperty {}
