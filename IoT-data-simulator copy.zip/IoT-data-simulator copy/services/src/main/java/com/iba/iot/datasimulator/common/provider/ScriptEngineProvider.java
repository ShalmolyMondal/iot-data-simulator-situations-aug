package com.iba.iot.datasimulator.common.provider;

import javax.script.ScriptEngine;

/**
 *
 */
public interface ScriptEngineProvider {

    /**
     *
     * @return
     */
    ScriptEngine get();

}
