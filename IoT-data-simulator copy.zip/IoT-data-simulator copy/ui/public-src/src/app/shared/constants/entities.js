

export default {

    session: 'session',
    definition: 'definition',
    device: 'device',
    system: 'system'

}