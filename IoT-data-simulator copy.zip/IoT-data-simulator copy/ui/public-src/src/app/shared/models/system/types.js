export default [
    { label: "AMQP", value: "amqp_broker" },
    { label: "Dummy", value: "dummy" },
    { label: "MQTT", value: "mqtt_broker" },
    { label: "Local object storage", value: "s3" },
    { label: "Kafka", value: "kafka_broker" },
    { label: "REST", value: "rest_endpoint" },
    { label: "Websocket", value: "websocket_endpoint" },
]