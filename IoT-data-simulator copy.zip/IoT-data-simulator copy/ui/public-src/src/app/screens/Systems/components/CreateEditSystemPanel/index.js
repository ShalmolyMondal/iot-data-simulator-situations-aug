import CreateEditSystemPanel from './CreateEditSystemPanel';
export default CreateEditSystemPanel;