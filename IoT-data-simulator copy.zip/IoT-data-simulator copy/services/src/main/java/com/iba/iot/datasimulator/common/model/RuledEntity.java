package com.iba.iot.datasimulator.common.model;

/**
 *
 * @param <T>
 */
public interface RuledEntity<T> {

    /**
     *
     * @return
     */
    T getRule();

}
