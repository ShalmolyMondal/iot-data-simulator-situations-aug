import './base.css';
import './normalize.css';

import themeConfig from './theme';

export default { 
    theme: themeConfig.theme
}