import DefinitionWizard from './DefinitionWizard';
export default DefinitionWizard;