package com.iba.iot.datasimulator.common.service.parser;

/**
 *
 */
public enum SchemaPropertyType {

    /** **/
    INTEGER,

    /** **/
    DOUBLE,

    /** **/
    LONG,

    /** **/
    STRING,

    /** **/
    BOOLEAN,

    /** **/
    DATE,

    /** **/
    TIMESTAMP
}
