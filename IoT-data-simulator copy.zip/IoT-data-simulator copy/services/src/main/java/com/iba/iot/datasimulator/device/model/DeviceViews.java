package com.iba.iot.datasimulator.device.model;

/**
 *
 */
public interface DeviceViews {

    /**
     *
     */
    interface Short {}
}
