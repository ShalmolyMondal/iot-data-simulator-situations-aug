package com.iba.iot.datasimulator.common.model.schema;

/**
 *
 */
public interface SchemaViews {

    /**
     *
     */
    interface Short {}

}
