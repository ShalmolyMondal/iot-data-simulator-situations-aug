import ViewLayout from './ViewLayout';
export default ViewLayout;